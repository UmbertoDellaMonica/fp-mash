// Copyright © 2015, Battelle National Biodefense Institute (BNBI)
// All rights reserved. Authored by: Brian Ondov, Todd Treangen,
// Sergey Koren, and Adam Phillippy
//
// See the LICENSE.txt file included with this software for license information.

// Versione del software
static const char* SOFTWARE_VERSION = "2.3";

